<?php
define('PROJECT_HTTP_ROOT', '/atlas/');
define('PROJECT_ROOT', $_SERVER['DOCUMENT_ROOT'].PROJECT_HTTP_ROOT);
define('PROJECT_KEY', '');
define('PROJECT_VERSION', '0.4.3');
define('PROJECT_HOST', 'localhost');
define('PROJECT_SGBD', 'mysql');
define('PROJECT_BASE', 'atlas');
define('PROJECT_USER', 'root');
define('PROJECT_PASSWORD', '');
define('PROJECT_CONTROLLER', '');

?>

